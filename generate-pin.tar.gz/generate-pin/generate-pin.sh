#!/bin/bash

# generate-pin.sh - 4 digit PIN generator

PIN=$(shuf -i 0000-9999 -n 1)
echo "Generated PIN: $PIN"
